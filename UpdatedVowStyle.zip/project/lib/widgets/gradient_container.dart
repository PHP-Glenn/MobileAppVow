import 'package:flutter/material.dart';

class GradientContainer extends StatelessWidget {
  final Widget child;
  final String imageUrl;

  const GradientContainer({
    super.key,
    required this.child,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: NetworkImage(imageUrl),
          fit: BoxFit.cover,
        ),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white.withOpacity(0.8),
              Colors.white.withOpacity(0.8),
            ],
          ),
        ),
        child: child,
      ),
    );
  }
}