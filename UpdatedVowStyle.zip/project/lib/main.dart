import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/collection_screen.dart';
import 'screens/designer_screen.dart';
import 'screens/appointment_screen.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const VowStyleApp());
}

class VowStyleApp extends StatelessWidget {
  const VowStyleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VowStyle',
      theme: AppTheme.theme,
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const HomeScreen(),
    const CollectionScreen(),
    const DesignerScreen(),
    const AppointmentScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Theme.of(context).primaryColor,
        unselectedItemColor: Color(0xFF2C3E50),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.collections), label: 'Collection'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Designers'),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_today), label: 'Book'),
        ],
      ),
    );
  }
}