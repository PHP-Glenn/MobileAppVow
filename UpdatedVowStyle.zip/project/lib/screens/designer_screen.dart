import 'package:flutter/material.dart';

class DesignerScreen extends StatelessWidget {
  const DesignerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Our Designers'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: designers.length,
        itemBuilder: (context, index) {
          return DesignerCard(designer: designers[index]);
        },
      ),
    );
  }
}

class Designer {
  final String name;
  final String title;
  final String bio;
  final List<String> specialties;
  final String imageUrl;

  Designer({
    required this.name,
    required this.title,
    required this.bio,
    required this.specialties,
    required this.imageUrl,
  });
}

final List<Designer> designers = [
  Designer(
    name: 'Jay-ann Gomolon',
    title: 'Head Designer',
    bio: 'Leading our creative vision with over 15 years of experience in luxury bridal fashion.',
    specialties: ['Couture', 'Modern', 'Luxury'],
    imageUrl: 'https://example.com/designer1.jpg',
  ),
  // Add more designers here
];

class DesignerCard extends StatelessWidget {
  final Designer designer;

  const DesignerCard({super.key, required this.designer});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundImage: NetworkImage(designer.imageUrl),
                  onBackgroundImageError: (exception, stackTrace) {},
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        designer.name,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        designer.title,
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(designer.bio),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: designer.specialties.map((specialty) {
                return Chip(label: Text(specialty));
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}